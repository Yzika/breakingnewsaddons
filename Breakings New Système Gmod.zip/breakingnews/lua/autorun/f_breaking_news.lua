FBreakingNews = FBreakingNews or {}
local folder = "f_breaking_news"

if SERVER then
	include(string.format("%s/server/sv_hooks.lua", folder))
	include(string.format("%s/server/sv_nets.lua", folder))

	AddCSLuaFile(string.format("%s/client/cl_interface.lua", folder))
	AddCSLuaFile(string.format("%s/client/cl_fonts.lua", folder))

	-- Resources
	resource.AddSingleFile("fonts/Montserrat-Regular.ttf")
	resource.AddSingleFile("fonts/Montserrat-Bold.ttf")
end

if CLIENT then
	include(string.format("%s/client/cl_interface.lua", folder))
	include(string.format("%s/client/cl_fonts.lua", folder))
end
