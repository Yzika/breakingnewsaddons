for i = 10, 30 do
	surface.CreateFont("FBNFontB"..i, {
		font = "Montserrat Bold",
		size = i,
		weight = 500
	})
end
