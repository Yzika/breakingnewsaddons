local TIMER_REMOVE = 30

net.Receive("FBN:OpenMenu", function()
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW() * 0.18, ScrH() * 0.13)
	frame:Center()
	frame:MakePopup()
	frame:DockPadding(0, 0, 0, 0)
	frame.Paint = function(s, w, h)
		draw.RoundedBox(6, 0, 0, w, h, Color(149, 165, 166))
		draw.SimpleText("Veuillez entrer votre news ci-dessous :", "FBNFontB15", ScrW()*0.005, ScrH()*0.037, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end

	local header = frame:Add("DPanel")
	header:Dock(TOP)
	header.Paint = function(s, w, h)
		draw.RoundedBoxEx(6, 0, 0, w, h, Color(192, 57, 43), true, true)
		draw.SimpleText("Breaking News", "FBNFontB17", ScrW()*0.005, ScrH()*0.0028, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end

	local close = header:Add("DButton")
	close:SetSize(header:GetTall(), header:GetTall())
	close:SetText("")
	close:Dock(RIGHT)
	close.DoClick = function() frame:Remove() end
	close.Paint = function(s, w, h)
		draw.RoundedBoxEx(6, 0, 0, w, h, Color(231, 76, 60), false, true)
		draw.SimpleText("x", "FBNFontB15", w/2 - ScrW()*0.00052, h/2 - ScrH()*0.00093, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local text = frame:Add("DTextEntry")
	text:SetSize(frame:GetWide() - ScrW()*0.005, ScrH()*0.0185)
	text:SetPlaceholderText("Texte de la news")
	text:Center()

	local send = frame:Add("DButton")
	send:SetSize(frame:GetWide(), ScrH()*0.0185)
	send:Dock(BOTTOM)
	send:SetText("")
	send.Paint = function(s, w, h)
		draw.RoundedBoxEx(6, 0, 0, w, h, Color(127, 140, 141), false, false, true, true)
		draw.SimpleText("Confirmer", "FBNFontB15", w/2 - ScrW()*0.00052, h/2 - ScrH()*0.00093, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	send.DoClick = function()
		if text:GetValue() == "" or text:GetValue() == " " or text:GetValue() == nil then return end

		net.Start("FBN:AddNews")
			net.WriteString(text:GetValue())
		net.SendToServer()

		frame:Remove()
	end
end)

local frame
net.Receive("FBN:AddNews", function()
	local text = net.ReadString()

	if IsValid(frame) then frame:Close() end

	frame = vgui.Create("DFrame")
	frame:SetSize(ScrW()*0.4167, ScrH()*0.0648)
	frame:SetPos(0, ScrH() - ScrH()*0.204)
	frame:ShowCloseButton(false)
	frame:DockPadding(0, 0, 0, 0)
	frame:SetTitle("")
	frame.posX = ScrW()*0.0833
	frame.Paint = function(s, w, h)
		s.posX = s.posX + 0.2
		if s.posX >= ScrW()*0.4167 then s.posX = ScrW()*0.0833 end


		draw.RoundedBox(0, 0, 0, w, h, color_white)
		draw.RoundedBox(0, 0, 0, ScrW()*0.073, h, Color(231, 76, 60))
		draw.SimpleText("BREAKINGNEWS", "FBNFontB20", ScrW()*0.0364, h/2 - ScrH()*0.05, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("NOM DU SERVEUR", "FBNFontB17", ScrW()*0.0364, h/2 + ScrH()*0.02, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		draw.SimpleText(text:sub(1, 1):upper()..text:sub(2)..".", "FBNFontB17", s.posX, h/2, Color(127, 140, 141), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	timer.Create("FBN:RemoveScreen", TIMER_REMOVE, 1, function()
		frame:Close()
	end)
end)

net.Receive("FBN:RemoveNew", function()
	if IsValid(frame) then frame:Close() end
end)
