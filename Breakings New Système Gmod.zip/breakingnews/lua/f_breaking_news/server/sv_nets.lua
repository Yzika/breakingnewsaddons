util.AddNetworkString("FBN:OpenMenu")
util.AddNetworkString("FBN:AddNews")
util.AddNetworkString("FBN:RemoveNew")

net.Receive("FBN:AddNews", function(len, ply)
	if not IsValid(ply) then return end
	if not team.GetName(ply:Team()) == "Journaliste" then return end

	local text = net.ReadString()

	net.Start("FBN:AddNews")
		net.WriteString(text)
	net.Broadcast()
end)
