hook.Add("PlayerSay", "FBN:OpenMenu", function(ply, text)
	if string.sub(string.lower(text), 1, 6) == "!bnews" then
		if IsValid(ply) then
			if team.GetName(ply:Team()) == "Citizen" then
			--if team.GetName(ply:Team()) == "Journaliste" then
				net.Start("FBN:OpenMenu")
				net.Send(ply)

				return ""
			else
				DarkRP.notify(ply, 1, 5, "Vous devez être journaliste pour utiliser cette commande.")
			end
		end
	end
end)

hook.Add("PlayerSay", "FBN:RemoveNew", function(ply, text)
	if string.sub(string.lower(text), 1, 11) == "!removenews" then
		if IsValid(ply) then
			if ply:IsAdmin() then
				net.Start("FBN:RemoveNew")
				net.Broadcast()

				return ""
			end
		end
	end
end)
